package server;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import common.InterfazDeServer;
import common.Persona;

public class ServerImpl implements InterfazDeServer {
	private Persona persona1 = new Persona("Fernando","2015-05-19",100000);
	private Persona persona2 = new Persona("Fernanda","2015-05-19",100000);
	private ArrayList<Persona> bdPersonas = new ArrayList<>();
	
	public ServerImpl() throws RemoteException {
		crearBd();
		conectarBD();
		UnicastRemoteObject.exportObject(this, 0);
	}
	public void conectarBD() {
		Connection connection = null;
		Statement query = null;
		//PreparedStatement test = null;
		ResultSet resultados = null;
		
		
		try {
			String url = "jdbc:mysql://localhost:3306/bd_tarea";
			String username = "root";
			String password_BD = "";
			
			connection = DriverManager.getConnection(url, username, password_BD);
			
			//TODO Metodos con la BD
			query = connection.createStatement();
			String sql = "SELECT * FROM cliente";
			//INSERT para agregar datos a la BD, PreparedStatement
			
			resultados = query.executeQuery(sql);
			
			while (resultados.next()) {
				
				String nombre = resultados.getString("nombre");
				String fechaNacimiento = resultados.getString("fechaNacimiento");
				int rut = resultados.getInt("rut");
				
				Persona newPersona = new Persona(nombre, fechaNacimiento, rut);
				
				bdPersonas.add(newPersona);
				
			}
			connection.close();
			
		} catch(SQLException e) {
			e.printStackTrace();
			System.out.println("No se pudo conectar a la BD :C");
		}
	}
	
	public void crearBd() {
		bdPersonas.add(persona1);
		bdPersonas.add(persona2);
	}
	
	@Override
	public ArrayList<Persona> getPersonas() throws RemoteException {
			return bdPersonas;
	}

	
	@Override
	public void Persona(String nombre, String fechaNacimiento, int rut) throws RemoteException {

		
	}
	@Override
    public void agregarPersona(String nombre, String fechaNacimiento, int rut) throws RemoteException {
    	Persona newPersona = new Persona(nombre, fechaNacimiento, rut);
        bdPersonas.add(newPersona);
        System.out.println("Se ha agregado una nueva persona: " + newPersona.getNombre());
    }

	
}
