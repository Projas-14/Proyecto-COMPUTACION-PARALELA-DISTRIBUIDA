
module distribuida {
	requires java.rmi;
	exports common;
	requires java.sql;
}