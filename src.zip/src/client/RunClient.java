package client;


import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.Scanner;

import common.ApiExterna;

public class RunClient {
    public static void main(String[] args) throws RemoteException, NotBoundException {
        Client client = new Client();
        client.startClient();

        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("Menu:");
            System.out.println("1. Agregar Persona");
            System.out.println("2. Mostrar Personas");
            System.out.println("3. Llamar API Externa");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); 

            switch (opcion) {
                case 1:
                    client.agregarPersona();
                    break;
                case 2:
                    client.getPersonas();
                    break;
                case 3:
                    ApiExterna apiExterna = new ApiExterna();
                    apiExterna.obtenerTasasDeCambio();
                    break;
                case 4:
                    System.out.println("Saliendo del programa.");
                    break;
                default:
                    System.out.println("Opción no válida. Por favor, seleccione una opción válida.");
                    break;
            }
        } while (opcion != 4);

        scanner.close();
    }
}

