package client;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.ArrayList;
import java.util.Scanner;

import common.InterfazDeServer;
import common.Persona;


public class Client {
	private InterfazDeServer server;
	private Scanner scanner;
	
	public Client() {
		scanner = new Scanner(System.in);
	}
	
	public void startClient() throws RemoteException, NotBoundException {
		Registry registry = LocateRegistry.getRegistry("localhost", 1099);
		server = (InterfazDeServer) registry.lookup("server");
	}
	

    public void agregarPersona() throws RemoteException {
        System.out.println("Ingrese el nombre de la nueva persona:");
        String nombre = scanner.nextLine();
        
        System.out.println("Ingrese la fecha de nacimiento");
        String fecha = scanner.nextLine();
        
        
        System.out.println("Ingrese el rut");
        int rut = Integer.parseInt(scanner.nextLine());
        

        server.agregarPersona(nombre,fecha ,rut);
        System.out.println("Se ha agregado una nueva persona: " + nombre);
    }
    public void getPersonas() throws RemoteException {
        ArrayList<Persona> personas = server.getPersonas();
        for (Persona persona : personas) {
        	System.out.println(persona.getNombre()+ " " + persona.getRut()+ " " + persona.getFechaNacimiento());
        }

    }
}
