package common;

import java.io.Serializable;

public class Persona implements Serializable{
	private static final long serialVersionUID = 1L;
	private String nombre;
	private String fechaNacimiento;
	private int rut;
	private int monto;
	
	public Persona(String nombre ,String fechaNacimiento, int rut) {
		this.nombre = nombre;
		this.fechaNacimiento = 	fechaNacimiento;
		this.rut = 	rut;
		
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public String getFechaNacimiento() {
		return fechaNacimiento;
	}
	
	public int getRut() {
		return rut;
	}
	public int getMonto() {
		return monto;
	}
	
}
