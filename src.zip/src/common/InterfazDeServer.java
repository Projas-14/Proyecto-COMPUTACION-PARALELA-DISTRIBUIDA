package common;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;

public interface InterfazDeServer extends Remote {
	//public ArrayList<Persona> getPersonas() throws RemoteException;
	public void Persona(String nombre, String fechaNacimiento, int rut) throws RemoteException;
	void agregarPersona(String nombre, String fechaNacimiento, int rut) throws RemoteException;
	ArrayList<common.Persona> getPersonas() throws RemoteException;
}
