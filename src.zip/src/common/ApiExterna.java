package common;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class ApiExterna {
    private static final String API_KEY = "35d4e193f3b64c449f5dc71c05eb7b80"; // Reemplaza "TU_APP_ID" con tu App ID

    public void obtenerTasasDeCambio() {
        String urlString = "https://openexchangerates.org/api/latest.json?app_id=" + API_KEY;
        URL url;
        try {
            url = new URL(urlString);
        } catch (MalformedURLException e) {
            System.err.println("La URL no es válida: " + e.getMessage());
            return; // Salimos del método si hay una excepción al crear la URL
        }

        HttpURLConnection con = null;
        try {
            con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");

            int status = con.getResponseCode();
            if (status == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                String inputLine;
                StringBuilder content = new StringBuilder();
                while ((inputLine = in.readLine()) != null) {
                    content.append(inputLine);
                }
                in.close();

                // Aquí procesas los datos recibidos
                System.out.println("Datos recibidos de Open Exchange Rates: " + content.toString());
            } else {
                System.out.println("Error al conectarse a la API de Open Exchange Rates. Código de estado: " + status);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (con != null) {
                con.disconnect();
            }
        }
    }
}


